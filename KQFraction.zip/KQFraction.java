
import java.util.Scanner;

public class Fraction {
    private int numerator, demonitor;
    Fraction(){
        this.setDemonitor(1);
    }
    void setNumerator(int num){
        numerator = num;
    }
    void setDemonitor(int dem){
        if (dem!=0) demonitor = dem;
    }
    public int getDemonitor(){
        return demonitor;
    }
    public int getNumerator() {
        return numerator;
    }
    Fraction(int numerator, int demonitor){
        this.setNumerator(numerator);
        this.setDemonitor(demonitor);
    }
    int gcd(int a, int b){
        /** a = b*q+r**/
        if (b==0) return a;
        return gcd(b,a%b);
    }
    Fraction(Fraction a){
        this.numerator = a.getNumerator();
        this.demonitor = a.getDemonitor();
    }
    void reduce(){
        int b = gcd(this.numerator, this.demonitor);
        this.numerator /=b;
        this.demonitor/=b;
    }
    Fraction add(Fraction a){
        this.numerator = a.numerator * this.demonitor + a.demonitor * this.numerator;
        this.demonitor = a.demonitor * this.demonitor;
        this.reduce();
        return this;
    }
    Fraction subtract(Fraction a){
        this.numerator = -a.numerator * this.demonitor + a.demonitor * this.numerator;
        this.demonitor = a.demonitor * this.demonitor;
        this.reduce();
        return this;
    }
    Fraction multiply(Fraction a){
        if(a.getNumerator()==0) return this;
        this.numerator = a.numerator * this.numerator;
        this.demonitor = a.demonitor * this.demonitor;
        this.reduce();
        return this;
    }
    Fraction divide(Fraction a){
        this.demonitor = a.numerator * this.demonitor;
        this.numerator = a.demonitor * this.numerator;
        this.reduce();
        return this;
    }
    public boolean equals(Object obj) {
        if (obj instanceof Fraction){
             Fraction other = (Fraction) obj;
             this.reduce();
             other.reduce();
        if(this.getNumerator() == other.getNumerator() && this.getDemonitor() == other.getDemonitor()){
            return true;
        }
        }
        return false;
    }
}

